import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
 import { CustomValidator } from '../login/login.component';
import { Employee } from '../Employee';
import {GlobalService} from './../services/global.service';
export function MustMatch(controlName: string, matchingControlName: string) {
  return (formGroup: FormGroup) => {
      const control = formGroup.controls[controlName];
      const matchingControl = formGroup.controls[matchingControlName];

      if (matchingControl.errors && !matchingControl.errors.mustMatch) {
          // return if another validator has already found an error on the matchingControl
          return;
      }

      // set error on matchingControl if validation fails
      if (control.value !== matchingControl.value) {
          matchingControl.setErrors({ mustMatch: true });
      } else {
          matchingControl.setErrors(null);
      }
  }
}



@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
    dbskills:any
    response:any
    emp:Employee
  registerForm: FormGroup;
  loading = false;
  submitted = false;
  dbTier:any;
  constructor(
      private formBuilder: FormBuilder,
      private router: Router,
      private myService:GlobalService
  ) { }
     

  ngOnInit() {



    this.myService.getSkills().subscribe((res:any)=>{
        console.log("skill results",res)
        this.dbskills=res;
        })

        this.myService.getTier().subscribe((res:any)=>{
            console.log("skill results",res)
            this.dbTier=res;
          })


      this.registerForm = this.formBuilder.group({
          firstName: ['', Validators.required],
          lastName: ['', Validators.required],
          tier: ['', Validators.required],
          primary: ['', Validators.required],
          skill: ['', Validators.required],
          email: ['', Validators.required],

          employeeid: ['', [Validators.required, Validators.minLength(7), Validators.maxLength(7), CustomValidator.findOnlyNumbers()]],
          // experience: ['', [Validators.required, Validators.maxLength(2), Validators.pattern('^0-9')]],
          experience: ['',  Validators.compose([Validators.required, Validators.maxLength(2),
              CustomValidator.findOnlyNumbers()])],

          password: ['', [Validators.required, Validators.minLength(6)]],
          confirmPassword: ['', Validators.required]
      }, {
          validator: MustMatch('password', 'confirmPassword')
      });
  }
  // convenience getter for easy access to form fields
  get f() { return this.registerForm.controls; }
email:any
password:any
  onSubmit() {
      console.log('sulli')
      this.submitted = true;

      // stop here if form is invalid
    //   if (this.registerForm.invalid) {
    //       return;
    //   }


      this.emp=new Employee(this.registerForm.get('employeeid').value,this.registerForm.get('firstName').value,this.registerForm.get('lastName').value,this.registerForm.get('experience').value,this.registerForm.get('tier').value,this.registerForm.get('skill').value,this.registerForm.get('email').value,this.registerForm.get('password').value,"No")
console.log("here here here")
console.log(this.emp)
      this.email=this.registerForm.get('email').value
      this.password=this.registerForm.get('password').value
      this.myService.postEmployees( this.emp).subscribe(
        (res) => {
            console.log("here");
            console.log(this.emp)
        this.response=res;
        console.log(res)
        this.router.navigate(['/']);
      },
        (err) => console.log(err)
        );
 }
}