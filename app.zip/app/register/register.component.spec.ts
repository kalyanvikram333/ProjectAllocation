import { TestBed, async } from "@angular/core/testing";
import { RouterTestingModule } from '@angular/router/testing';
import {ReactiveFormsModule, FormsModule} from '@angular/forms';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { RegisterComponent } from './register.component';
import { By } from '@angular/platform-browser';

describe('RegisterComponent', () => {
    beforeEach(async(() => {
      TestBed.configureTestingModule({
        imports: [
          RouterTestingModule,
          ReactiveFormsModule,
          FormsModule,
          HttpClientTestingModule
        ],
        declarations: [
            RegisterComponent
        ],
      }).compileComponents();
    }));
  



    it('should show the input text field as employee id ',() =>{
     
        const fixture =TestBed.createComponent(RegisterComponent);
        const demo = fixture.debugElement.componentInstance;
        const userNameElement = fixture.debugElement.query(By.css('input[id=emplId]'));
        expect(userNameElement.nativeElement.innerHTML).toBe('');
    });

    it('should show the input text field as first name ',() =>{
     
        const fixture =TestBed.createComponent(RegisterComponent);
        const demo = fixture.debugElement.componentInstance;
        const userNameElement = fixture.debugElement.query(By.css('input[id=fname]'));
        expect(userNameElement.nativeElement.innerHTML).toBe('');
    });

    it('should show the input text field as last name ',() =>{
     
        const fixture =TestBed.createComponent(RegisterComponent);
        const demo = fixture.debugElement.componentInstance;
        const element = fixture.debugElement.query(By.css('input[id=lname]'));
        expect(element.nativeElement.innerHTML).toBe('');
    });

    it('should show the input text field as password ',() =>{
     
        const fixture =TestBed.createComponent(RegisterComponent);
        const demo = fixture.debugElement.componentInstance;
        const element = fixture.debugElement.query(By.css('input[id=password]'));
        expect(element.nativeElement.innerHTML).toBe('');
    });

    it('should show the input text field as tier ',() =>{
     
        const fixture =TestBed.createComponent(RegisterComponent);
        const demo = fixture.debugElement.componentInstance;
        const passwordElement = fixture.debugElement.query(By.css('select[id=tier]'));
        expect(passwordElement.nativeElement.innerHTML).toBeTruthy();
    });

     it('should show the input text field as submit ',() =>{
     
        const fixture =TestBed.createComponent(RegisterComponent);
        const demo = fixture.debugElement.componentInstance;
        const submitElement = fixture.debugElement.query(By.css('button'));
        expect(submitElement.nativeElement.innerHTML).toBeTruthy();
    });


});