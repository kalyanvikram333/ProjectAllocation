import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class GlobalService {
  ID:number;

  constructor(private http:HttpClient) { }


  setempid(id: number) {
    this.ID = id;
  }

  getEmpId(){
    return this.ID;
  }

  getSkills(){
    return this.http.get<any>('http://localhost:8080/skills').pipe();
  }
  postSkills(inputSkill){
    return this.http.post<any>('http://localhost:8080/saveSkills',inputSkill);
  }

  getTier(){
    return this.http.get<any>('http://localhost:8080/tier/tiers').pipe();
  }

  postOpening(openings){
    return this.http.post<any>('http://localhost:8080/opening/saveOpening',openings);
  }

  getEmployee(){
    return this.http.get<any>('http://localhost:8080/employee/all').pipe();
  }
  getOpening(){
    return this.http.get<any>('http://localhost:8080/opening/openings').pipe();
  }


  postApplications(app) {
    console.log("hello")
    console.log(app)
    return this.http.post<any>('http://localhost:8080/app/applications', app);
  }

  getProjects(){
    return this.http.get<any>('http://localhost:8080/opening/openings').pipe();
  }

  loginValidation(res){
    // console.log(empid)
     return this.http.post<any>('http://localhost:8080/employee/login',res);
   }

   postEmployees(emp) {
    return this.http.post<any>('http://localhost:8080/employee/create', emp);

  }

  postSkillsSendEmpId(id1){
    console.log('id1 mghhj')
    return this.http.post<any>('http://localhost:8080/employee/id',id1);
  }

  getSkillsofEmp(){
    console.log("hello world")
    return this.http.get<any>('http://localhost:8080/employee/getskills').pipe();
  }

  postUpdateSkill(inputSkill){
    console.log(inputSkill)
    return this.http.post<any>('http://localhost:8080/employee/updateSkills',inputSkill);
  }
  postUpdateSkillEmpid(empid){
    console.log(empid)
    return this.http.post<any>('http://localhost:8080/employee/updateSkillsempId',empid);
  }

  getApplications(){
    return this.http.get<any>('http://localhost:8080/app/jobs').pipe();
  }

}
