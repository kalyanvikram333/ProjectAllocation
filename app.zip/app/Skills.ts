export class Skills{
    skills:string
    constructor(skills:string){
        this.skills=skills
    }
}