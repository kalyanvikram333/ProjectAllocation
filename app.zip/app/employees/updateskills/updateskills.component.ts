import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Skills } from './../../Skills';
import { GlobalService } from './../../services/global.service'
import { deepEqual } from 'assert';
import { Router } from '@angular/router';
@Component({
  selector: 'app-updateskills',
  templateUrl: './updateskills.component.html',
  styleUrls: ['./updateskills.component.css']
})
export class UpdateskillsComponent implements OnInit {
  ///should be taken once logged in
  dbskills: any
  EmpSkills: Array<Skills>
  resSkills: Array<Skills>
  temp1:any;
  name = "_NAME_";
  submitted = false;
  updateForm: FormGroup
  GlobalService: any;
  constructor(private formBuilder: FormBuilder, private myService: GlobalService,private route:Router) { }
  //empId=123;
  //empId = 123
 // empId:number
  //
 
  //constructor() { }
  temp: any
  skill: Skills
  response: any
  empId:number




  ngOnInit() {
    //this.empId=
    this.empId=this.myService.getEmpId()
    console.log(this.empId,'here');
    // empId=123;
    this.updateForm = this.formBuilder.group({

      skill: ['', Validators.required],

    });

    this.myService.postSkillsSendEmpId(this.empId).subscribe(
      (res) => {
        console.log('get1 called', res)
        this.response = res;
       
      },

      (err) => console.log(err)
    );
    this.myService.getSkillsofEmp().subscribe((res: any) => {
      this.EmpSkills = res;
      console.log("skill of employee", res)

    })

       // var i;

    this.myService.getSkills().subscribe((res: any) => {
      console.log("skill results", res)
      this.dbskills = res;
      this.temp = this.dbskills;
    })
    // for(let i in this.dbskills){
      //this.myService.postUpdateSkill(this.EmpSkills).subscribe();
     
  }

  onSubmit() {
    console.log('qwer', this.temp);
    this.submitted = true;
    if (this.updateForm.invalid) {
      return;
    }
    alert('SUCCESS!!')
    this.skill = new Skills(this.updateForm.get('skill').value);
    this.myService.postUpdateSkill(this.skill.skills).subscribe();
    this.myService.postUpdateSkillEmpid(this.empId).subscribe();
    this.route.navigate(['/employees']);
  }


  get f() {
    return this.updateForm.controls;
   
   }
}
