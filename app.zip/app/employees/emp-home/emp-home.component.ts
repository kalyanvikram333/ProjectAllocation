import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import {GlobalService} from './../../services/global.service';
import{Application} from './../../Application';
import{Project} from './../../Project';
import {FormBuilder,FormGroup, Validators, NgForm}
  from '@angular/forms';
@Component({
  selector: 'app-emp-home',
  templateUrl: './emp-home.component.html',
  styleUrls: ['./emp-home.component.css']
})
export class EmpHomeComponent implements OnInit {


  dbProjects:any;
  constructor (private httpService:HttpClient,private myService:GlobalService,private formBuilder: FormBuilder) { }
  projects: string [];
  p: Number = 1;
  count: Number = 4;
empId=this.myService.ID;
app:Application
proj:Project
response:any
addjobF: any;
userName='';
client:any;
i:any;
p1:Project

checkApplication:any

proje:Array<Project>;
applicationsArray:Array<Application>


reg(){
  //$('#client').html()
  //console.log(this.client);
 // console.log(this.userName);
  //console.log(this.addjobF.get('client').value);


}

onFormSubmit(i:any) {
  //console.log("test");
  this.i=i;
 // console.log(i);
  this.proje=this.dbProjects;
  console.log(this.dbProjects,'sfdjsfgjghj')
  this.p1 = new Project(this.proje[i].projectId,"",1,"","","")
  this.app = new Application(this.empId,this.proje[i].projectId);



 
 this.myService.postApplications(this.app).subscribe(
 (res) => {
   console.log("here")
   console.log(this.app)
 this.response=res;
 console.log(res)
 if(res=='OK'){
   alert('successfully applied')
 }else{
   alert('Already applied')
 }

},
 (err) => console.log(err)
 );
 
 
}
  ngOnInit () {

   
    // this.httpService.get('./assets/projectList.json').subscribe(
    //   data => {
    //     this.projects = data as string [];  // FILL THE ARRAY WITH DATA.
    //     //  console.log(this.arrBirds[1]);
    //   },
    //   (err: HttpErrorResponse) => {
    //     console.log (err.message);
    //   }
    // );

    this.myService.getProjects().subscribe((res1:any)=>{

      console.log("skills results",res1)
      console.log(this.empId)
      this.dbProjects=res1;
     
      })
     
     
  }
}