import { TestBed, async } from "@angular/core/testing";
import { RouterTestingModule } from '@angular/router/testing';
import {ReactiveFormsModule, FormsModule} from '@angular/forms';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { LoginComponent } from './login.component';
import { By } from '@angular/platform-browser';

describe('LoginComponent', () => {
    beforeEach(async(() => {
      TestBed.configureTestingModule({
        imports: [
          RouterTestingModule,
          ReactiveFormsModule,
          FormsModule,
          HttpClientTestingModule
        ],
        declarations: [
         LoginComponent
        ],
      }).compileComponents();
    }));
  



    it('should show the input text field as username ',() =>{
     
        const fixture =TestBed.createComponent(LoginComponent);
        const demo = fixture.debugElement.componentInstance;
        const userNameElement = fixture.debugElement.query(By.css('input[id=empId]'));
        expect(userNameElement.nativeElement.innerHTML).toBe('');
    });

    it('should show the input text field as password ',() =>{
     
        const fixture =TestBed.createComponent(LoginComponent);
        const demo = fixture.debugElement.componentInstance;
        const passwordElement = fixture.debugElement.query(By.css('input[id=password]'));
        expect(passwordElement.nativeElement.innerHTML).toBe('');
    });

    it('should show the input text field as submit ',() =>{
     
        const fixture =TestBed.createComponent(LoginComponent);
        const demo = fixture.debugElement.componentInstance;
        const submitElement = fixture.debugElement.query(By.css('button'));
        expect(submitElement.nativeElement.innerHTML).toBeTruthy();
    });


});