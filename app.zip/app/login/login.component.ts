import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ValidatorFn, AbstractControl } from '@angular/forms';
import {GlobalService}from './../services/global.service'
import { first } from 'rxjs/operators';
import { Employee } from '../Employee';
//import { Test1Component } from '../test1/test1.component';
import { empty } from 'rxjs';


export class CustomValidator {
  public static findOnlyNumbers(): ValidatorFn {
    return (c: AbstractControl): { [key: string]: boolean } | null => {
      // console.log('val:', c.value);
      let isDigit = false;
      let isCapsOrSmallLetter = false;
      // let isSmallLetter = false;
      let isSpecialChar = false;
      if ((!/\d/.test(c.value))) {
        // console.log('password must contain digits');
        isDigit = false;
      } else {
        isDigit = true;
      }
      if (/[A-Za-z]/.test(c.value)) {
        // console.log('password must contain uppercase letter');
        isCapsOrSmallLetter = false;
      } else {
        isCapsOrSmallLetter = true;
      }
      if (/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(c.value)) {
        // console.log('password must contain special character');
        isSpecialChar = false;
      } else {
        isSpecialChar = true;
      }

      if (isDigit && isCapsOrSmallLetter && isSpecialChar === true) {
        // null is required here. otherwise form wonot submit.
        return null
        console.log("Employee ID should be 7 digit number");
      }
      return { passwordval: false };
    };
  }
}





@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;
 response:any
 emp:Employee
  constructor(
    private formBuilder: FormBuilder,
    //private route: ActivatedRoute,
    private route: Router,
    private authenticationService: GlobalService,
  ) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      employeeid: ['', [Validators.required, Validators.minLength(7), Validators.maxLength(7), CustomValidator.findOnlyNumbers()]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      logintype: ['', Validators.required]
    });

    // get return url from route parameters or default to '/'
    //this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
  }

  // convenience getter for easy access to form fields
  get f() { return this.loginForm.controls; }
  uname:number
  pass:String
  res:any
  onSubmit() {
    console.log('test')
    this.submitted = true;

    // stop here if form is invalid
    // if (this.loginForm.invalid) {
    //   console.log('123')
    //   return;
    // }
   
   this.uname=this.loginForm.get('employeeid').value
   this.authenticationService.setempid( this.uname);
   //this.emp.empID(this.uname);
   console.log(this.authenticationService.getEmpId(),'from service')
  this.pass=this.loginForm.get('password').value
  this.res={'username':this.uname,'password':this.pass}
    console.log('uname ',this.loginForm.get('employeeid').value)
    console.log('pass ',this.loginForm.get('password').value)

this.authenticationService.loginValidation(this.res).subscribe((res) => {
  this.response=res;
  console.log(res,'dfshdhsfjhj')
  if(res=='LOCKED'){
   // alert('Duplicate')
 this.route.navigate(['/manager']);
  }else if(res=='OK'){
    //alert('Duplicate')
 this.route.navigate(['/employees']);
  }else{
    alert('Wrong Credentials')
 this.route.navigate(['/']);
  }


},
  (err) => console.log(err)
  );
    // this.loading = true;
    // this.authenticationService.login(this.loginForm.get('employeeid').value,this.loginForm.get('password').value)
    //     .pipe(first())
    //     .subscribe(
    //         data => {
    //             this.router.navigate([this.returnUrl]);
    //         },
    //         error => {
    //            // this.alertService.error(error);
    //             this.loading = false;
    //         });

  }
}
