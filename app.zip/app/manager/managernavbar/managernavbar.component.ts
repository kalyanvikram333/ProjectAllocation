import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managernavbar',
  templateUrl: './managernavbar.component.html',
  styleUrls: ['./managernavbar.component.css']
})
export class ManagernavbarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
