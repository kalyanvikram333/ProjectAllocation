import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {GlobalService} from './../../services/global.service'

@Component({
  selector: 'app-openings',
  templateUrl: './openings.component.html',
  styleUrls: ['./openings.component.css']
})
export class OpeningsComponent implements OnInit {
  title = 'JSON to Table Example';
  constructor (private httpService: HttpClient, private myservice:GlobalService) { }
  arrBirds: string [];
  dbOpening:any;
  p: Number = 1;
  count: Number = 8;
 
 // constructor() { }

 ngOnInit () {
  // this.httpService.get('./assets/test.json').subscribe(
  //   data => {
  //     this.arrBirds = data as string [];	 // FILL THE ARRAY WITH DATA.
  //     //  console.log(this.arrBirds[1]);
  //   },
  //   (err: HttpErrorResponse) => {
  //     console.log (err.message);
  //   }
  // );
 this.myservice.getOpening().subscribe((res:any)=>{
   console.log(res);
    this.dbOpening=res;
 })
}
}
