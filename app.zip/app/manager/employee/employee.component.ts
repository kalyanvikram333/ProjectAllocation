import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { GlobalService } from './../../services/global.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  title = 'JSON to Table Example';
  constructor (private httpService: HttpClient, private myService:GlobalService) { }
  arrBirds: string [];
  dbEmployee:any;
 
  p1:Number = 1;
  c: Number = 8;
 // constructor() { }

 ngOnInit () {
  // this.httpService.get('./assets/test.json').subscribe(
  //   data => {
  //     this.arrBirds = data as string [];	 // FILL THE ARRAY WITH DATA.
  //     //  console.log(this.arrBirds[1]);
  //   },
   
  //   (err: HttpErrorResponse) => {
  //     console.log (err.message);
  //   }
  // );
  this.myService.getEmployee().subscribe((res:any)=>{
    console.log("skills results",res)
    this.dbEmployee=res;
  });
}
}
