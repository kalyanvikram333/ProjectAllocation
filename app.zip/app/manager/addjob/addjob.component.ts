import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {GlobalService} from './../../services/global.service';
import {Openings} from './../../Openings'
import { Router } from '@angular/router';

@Component({
  selector: 'app-addjob',
  templateUrl: './addjob.component.html',
  styleUrls: ['./addjob.component.css']
})
export class AddjobComponent implements OnInit {

  submitted = false;
  addjobF: FormGroup;
  clientname:string;
  dbTier:any;
  dbOpening:any;
  response:any;
 open:Openings;
  constructor(private formBuilder: FormBuilder, private myService:GlobalService,private route:Router) { }


  //constructor() { }
  ngOnInit() {
    this.addjobF = this.formBuilder.group({
      client: ['', Validators.required],
      
      technology: ['',Validators.required],
      tier: ['',Validators.required],
      experience: ['',Validators.required],
      clien: ['',[Validators.required,Validators.maxLength(200)]]
      
     
  });

  this.myService.getTier().subscribe((res:any)=>{
    console.log("skill results",res)
    this.dbTier=res;
  })
  }
  get f() { return this.addjobF.controls; }
  // ngOnInit() {
  // }
  onSubmit() {
    this.submitted = true;
   
    // stop here if form is invalid
    if (this.addjobF.invalid) {
        return;
    }
   // this.open = new Openings(this.addjobF.get('client').value,this.addjobF.get('experience').value,this.addjobF.get('tier').value,this.addjobF.get('technology').value,this.addjobF.get('clien').value)
    this.open = new Openings(this.addjobF.get('client').value,this.addjobF.get('experience').value,this.addjobF.get('tier').value,this.addjobF.get('technology').value,this.addjobF.get('clien').value)

    this.myService.postOpening( this.open).subscribe(
      (res) => {
        this.response=res;
        console.log(res)
        alert('New opening has been added')
        this.route.navigate(['/manager']);
      },
      (err) => console.log(err)
    );
    //alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.addjobF.value))

}
}
