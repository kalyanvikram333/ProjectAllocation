import { Component, OnInit } from '@angular/core';
import {GlobalService} from './../../services/global.service'
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-addskill',
  templateUrl: './addskill.component.html',
  styleUrls: ['./addskill.component.css']
})
export class AddskillComponent implements OnInit {

  name="testname";
  submitted = false;
  addskillF: FormGroup
  dbSkills:any;
  inputSkill:string;
  response:any;
  constructor(private formBuilder: FormBuilder, private myService:GlobalService,private route:Router) { }

  //constructor() { }
  ngOnInit() {
    console.log("add skill component called")
    this.addskillF = this.formBuilder.group({
      additionalSkills: ['', Validators.required]
  });

  this.myService.getSkills().subscribe((res:any)=>{
    console.log("skills results",res)
    this.dbSkills=res;
  })
  }
  get f() { return this.addskillF.controls; }
  // ngOnInit() {
  // }
  onSubmit() {
    console.log("form value",this.addskillF.get('additionalSkills').value)
    this.submitted = true;
console.log("onsubmit")
    // stop here if form is invalid
    if (this.addskillF.invalid) {
        return;
    }
    
    this.inputSkill=this.addskillF.get('additionalSkills').value
    this.myService.postSkills( this.inputSkill).subscribe(
      (res) => {
        this.response=res;
        console.log("success",res)
        if(res=='CONFLICT'){
          alert('Duplicate')
          this.route.navigate(['/manager/addskill']);
        }
        if(res=='OK'){
          alert('Successfully added')
        }
      },
        
      (err) => console.log("error",err)
    );
    // this.addskillF.reset();
    // this.addskillF.markAsPristine();
    // this.addskillF.markAsUntouched();
    // this.addskillF.updateValueAndValidity();
    
    //alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.addskillF.value))
    if (this.addskillF.valid) {
      console.log("Form Submitted!");
      //this.addskillF.reset();
      this.route.navigate(['/manager']);
     
      // alert('SUCCESS!! :-)');
    }
    
  }
 
}
