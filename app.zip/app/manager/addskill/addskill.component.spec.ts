import { TestBed, async } from "@angular/core/testing";
import { RouterTestingModule } from '@angular/router/testing';
import {ReactiveFormsModule, FormsModule} from '@angular/forms';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { By } from '@angular/platform-browser';
import { AddskillComponent } from './addskill.component';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('AddskillComponent', () => {
    beforeEach(async(() => {
      TestBed.configureTestingModule({
        imports: [
          RouterTestingModule,
          ReactiveFormsModule,
          FormsModule,
          HttpClientTestingModule
        ],
        declarations: [
         AddskillComponent
         //ManagernavbarComponent
        ],
        schemas:[
            CUSTOM_ELEMENTS_SCHEMA
        ]
      }).compileComponents();
    }));
  

    it('should show the input text field as password ',() =>{
     
        const fixture =TestBed.createComponent(AddskillComponent);
        const demo = fixture.debugElement.componentInstance;
        const passwordElement = fixture.debugElement.query(By.css('input[id=askill]'));
        expect(passwordElement.nativeElement.innerHTML).toBe('');
    });


});