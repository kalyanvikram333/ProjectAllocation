import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { GlobalService } from './../../services/global.service';

@Component({
  selector: 'app-manager-home',
  templateUrl: './manager-home.component.html',
  styleUrls: ['./manager-home.component.css']
})
export class ManagerHomeComponent implements OnInit {

  title = 'JSON to Table Example';
  constructor (private httpService: HttpClient, private myService:GlobalService) { }
  arrBirds: string [];
  p: Number = 1;
  count: Number = 4;
  
  dbApplications:any;
 // constructor() { }

 ngOnInit () {
  // this.httpService.get('./assets/test.json').subscribe(
  //   data => {
  //     this.arrBirds = data as string [];	 // FILL THE ARRAY WITH DATA.
  //     //  console.log(this.arrBirds[1]);
  //   },
  //   (err: HttpErrorResponse) => {
  //     console.log (err.message);
  //   }
  // );


  this.myService.getApplications().subscribe((res:any)=>{
    console.log(res);
    console.log(this.dbApplications)
    this.dbApplications=res;
  })
}

}
